<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$user = 'ruletaabincom_usrrul';
$pass = 'hzOddq6Xx.vX';
$db = 'ruletaabincom_ruleta';

// Crear una nueva conexión a MySQL
$mysqli = new mysqli($host, $user, $pass, $db);

// Verificar si hay errores de conexión
if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}

// Retornar la conexión
return $mysqli;
?>
